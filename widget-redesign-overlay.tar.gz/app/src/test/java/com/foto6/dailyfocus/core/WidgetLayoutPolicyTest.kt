package com.foto6.dailyfocus.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class WidgetLayoutPolicyTest {
    @Test fun tinyWidgetShowsOneTask() = assertEquals(1, WidgetLayoutPolicy.forSize(250, 185).maxTasks)
    @Test fun boundary210ShowsTwoTasks() = assertEquals(2, WidgetLayoutPolicy.forSize(320, 210).maxTasks)
    @Test fun boundary250ShowsStatus() = assertTrue(WidgetLayoutPolicy.forSize(320, 250).showStatus)
    @Test fun boundary280ShowsAppsAndTwoTasks() {
        val layout = WidgetLayoutPolicy.forSize(320, 280)
        assertTrue(layout.showApps)
        assertEquals(2, layout.maxTasks)
    }
    @Test fun boundary300ShowsThreeTasks() = assertEquals(3, WidgetLayoutPolicy.forSize(320, 300).maxTasks)
    @Test fun boundary320ShowsFourTasks() = assertEquals(4, WidgetLayoutPolicy.forSize(320, 320).maxTasks)
    @Test fun narrowWidgetHidesSubtitle() = assertFalse(WidgetLayoutPolicy.forSize(250, 400).showSubtitle)
    @Test fun normalWidthShowsSubtitle() = assertTrue(WidgetLayoutPolicy.forSize(320, 400).showSubtitle)

    @Test fun stressPolicyInvariants() {
        val random = Random(0xD411F0C)
        repeat(100_000) {
            val width = random.nextInt(-200, 1_200)
            val height = random.nextInt(-200, 1_600)
            val layout = WidgetLayoutPolicy.forSize(width, height)
            assertTrue(layout.maxTasks in 1..4)
            if (height < 210) {
                assertFalse(layout.showStatus)
                assertFalse(layout.showApps)
                assertEquals(1, layout.maxTasks)
            }
            if (width < 280) assertFalse(layout.showSubtitle)
            if (layout.showApps) assertTrue(layout.showStatus)
        }
    }
}
