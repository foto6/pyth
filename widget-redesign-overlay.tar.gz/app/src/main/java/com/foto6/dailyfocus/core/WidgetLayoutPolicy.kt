package com.foto6.dailyfocus.core

data class WidgetLayout(
    val showSubtitle: Boolean,
    val showStatus: Boolean,
    val showApps: Boolean,
    val maxTasks: Int
)

object WidgetLayoutPolicy {
    /**
     * Conservative layout policy for RemoteViews. Secondary content is hidden
     * before it can clip on smaller Samsung home-screen grid sizes.
     */
    fun forSize(widthDp: Int, heightDp: Int): WidgetLayout {
        val safeWidth = widthDp.coerceAtLeast(0)
        val safeHeight = heightDp.coerceAtLeast(0)
        val narrow = safeWidth < 280
        return when {
            safeHeight < 210 -> WidgetLayout(false, false, false, 1)
            safeHeight < 250 -> WidgetLayout(!narrow, false, false, 2)
            safeHeight < 280 -> WidgetLayout(!narrow, true, false, 2)
            safeHeight < 300 -> WidgetLayout(!narrow, true, true, 2)
            safeHeight < 320 -> WidgetLayout(!narrow, true, true, 3)
            else -> WidgetLayout(!narrow, true, true, 4)
        }
    }

    fun forHeight(heightDp: Int): WidgetLayout = forSize(widthDp = 320, heightDp = heightDp)
}
