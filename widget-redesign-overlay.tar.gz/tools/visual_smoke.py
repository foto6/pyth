#!/usr/bin/env python3
"""Non-fatal widget visual preview generator.

Writes only to a confirmed writable directory. Preview generation is deliberately
non-fatal so a filesystem problem can never hide a valid Android build.
"""
from pathlib import Path
import html
import os
import tempfile


def choose_out():
    requested=os.environ.get('DAILYFOCUS_VISUAL_OUT')
    candidates=[]
    if requested:
        candidates.append(Path(requested))
    candidates.append(Path(tempfile.mkdtemp(prefix='dailyfocus_visual_')))
    for out in candidates:
        try:
            out.mkdir(parents=True, exist_ok=True)
            probe=out/'.write-test'
            probe.write_text('ok', encoding='utf-8')
            probe.unlink()
            return out
        except Exception as e:
            print(f'Visual output unavailable at {out}: {e}')
    return None


def layout_policy(width, height):
    narrow=width < 280
    if height < 210: return dict(subtitle=False,status=False,apps=False,tasks=1)
    if height < 250: return dict(subtitle=not narrow,status=False,apps=False,tasks=2)
    if height < 280: return dict(subtitle=not narrow,status=True,apps=False,tasks=2)
    if height < 300: return dict(subtitle=not narrow,status=True,apps=True,tasks=2)
    if height < 320: return dict(subtitle=not narrow,status=True,apps=True,tasks=3)
    return dict(subtitle=not narrow,status=True,apps=True,tasks=4)


def esc(s): return html.escape(s)


def preview(width, height):
    l=layout_policy(width,height)
    pad=10
    y=pad
    task_names=['Математика ЕГЭ','Повторить тригонометрию','30 мин Python','Проверить конспект']
    parts=[]
    parts.append(f'''<defs>
      <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#1083ca"/><stop offset=".58" stop-color="#b0d4ed"/><stop offset="1" stop-color="#aaba51"/></linearGradient>
      <linearGradient id="glass" x1="0" y1="0" x2="1" y2="0"><stop stop-color="#f6fbf0" stop-opacity=".94"/><stop offset="1" stop-color="#f4e9dc" stop-opacity=".95"/></linearGradient>
      <linearGradient id="progress" x1="0" y1="0" x2="1" y2="0"><stop stop-color="#1083ca"/><stop offset="1" stop-color="#639c49"/></linearGradient>
      <filter id="shadow"><feDropShadow dx="0" dy="4" stdDeviation="7" flood-opacity=".18"/></filter>
      <style>.title{{font:700 14px sans-serif;fill:#17313b}} .sub{{font:9px sans-serif;fill:#617882}} .time{{font:700 28px sans-serif;fill:#17313b}} .small{{font:10px sans-serif;fill:#617882}} .label{{font:700 11px sans-serif;fill:#17313b}} .task{{font:12px sans-serif;fill:#17313b}} .done{{font:12px sans-serif;fill:#6e8589}}</style>
    </defs>''')
    # Wallpaper-like test background to expose contrast problems.
    parts.append(f'<rect width="{width}" height="{height}" rx="28" fill="url(#wall)"/>')
    parts.append(f'<rect x="2" y="2" width="{width-4}" height="{height-4}" rx="28" fill="#f6f4e8" fill-opacity=".94" stroke="#ffffff" stroke-opacity=".55"/>')

    # Header 32
    cy=y+16
    parts.append(f'<text x="{pad+6}" y="{cy+5}" class="title">❋  Daily Focus</text>')
    if l['subtitle']:
        parts.append(f'<text x="{pad+6}" y="{cy+15}" class="sub">Спокойный прогресс на сегодня</text>')
    goal_x=width-pad-28-6-70
    parts.append(f'<rect x="{goal_x}" y="{y+2}" width="70" height="28" rx="14" fill="#fff2ce"/>')
    parts.append(f'<text x="{goal_x+35}" y="{y+20}" text-anchor="middle" style="font:700 11px sans-serif;fill:#9b654a">Цель 2ч</text>')
    parts.append(f'<circle cx="{width-pad-14}" cy="{y+16}" r="14" fill="#ffffff" fill-opacity=".42" stroke="#ffffff" stroke-opacity=".55"/>')
    parts.append(f'<text x="{width-pad-14}" y="{y+21}" text-anchor="middle" style="font:18px sans-serif;fill:#1083ca">↻</text>')
    y+=32

    # Metric block 38 + progress 9
    y+=4
    parts.append(f'<text x="{pad+6}" y="{y+28}" class="time">2ч 17м</text>')
    parts.append(f'<text x="{width-pad-6}" y="{y+27}" text-anchor="end" class="small">сегодня</text>')
    y+=34
    y+=3
    track_w=width-2*pad-12
    parts.append(f'<rect x="{pad+6}" y="{y}" width="{track_w}" height="6" rx="3" fill="#58727c" fill-opacity=".22"/>')
    parts.append(f'<rect x="{pad+6}" y="{y}" width="{track_w}" height="6" rx="3" fill="url(#progress)"/>')
    y+=6

    if l['status']:
        y+=5
        parts.append(f'<rect x="{pad+6}" y="{y}" width="154" height="24" rx="12" fill="#ddeed5"/>')
        parts.append(f'<text x="{pad+16}" y="{y+16}" style="font:700 11px sans-serif;fill:#3f7e3e">✓ Цель выполнена · +17м</text>')
        y+=24

    if l['apps']:
        y+=6
        gap=7
        card_w=(width-2*pad-12-gap)/2
        for i,(badge,name,t,fill,txt) in enumerate([
            ('F','Firefox','1ч 26м','#f5e0c8','#9b654a'),('AI','ChatGPT','51м','#dce9e2','#3f7e3e')]):
            x=pad+6+i*(card_w+gap)
            parts.append(f'<rect x="{x}" y="{y}" width="{card_w}" height="44" rx="16" fill="#ffffff" fill-opacity=".57" stroke="#ffffff" stroke-opacity=".42"/>')
            parts.append(f'<circle cx="{x+21}" cy="{y+22}" r="13.5" fill="{fill}"/>')
            parts.append(f'<text x="{x+21}" y="{y+26}" text-anchor="middle" style="font:700 10px sans-serif;fill:{txt}">{badge}</text>')
            parts.append(f'<text x="{x+41}" y="{y+18}" class="label">{name}</text>')
            parts.append(f'<text x="{x+41}" y="{y+32}" class="small">{t}</text>')
        y+=44

    y+=5
    parts.append(f'<text x="{pad+6}" y="{y+15}" class="label">Сегодняшние задачи</text>')
    parts.append(f'<text x="{width-pad-6}" y="{y+15}" text-anchor="end" class="small">1 / 4</text>')
    y+=22

    for i,name in enumerate(task_names[:l['tasks']]):
        done=i==0
        base=y+i*28
        mark='✓' if done else '○'
        color='#639c49' if done else '#899a9f'
        cls='done' if done else 'task'
        parts.append(f'<text x="{pad+9}" y="{base+19}" style="font:700 17px sans-serif;fill:{color}">{mark}</text>')
        parts.append(f'<text x="{pad+34}" y="{base+18}" class="{cls}">{esc(name)}</text>')
    bottom=y+l['tasks']*28+pad
    if bottom > height:
        raise AssertionError(f'preview overflow {width}x{height}: bottom={bottom}')

    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">'+''.join(parts)+'</svg>'


def main():
    try:
        out=choose_out()
        if out is None:
            print('Visual preview skipped: no writable directory')
            return 0
        sizes=[(250,185),(320,280),(320,320),(360,360)]
        for w,h in sizes:
            (out/f'widget_{w}x{h}.svg').write_text(preview(w,h),encoding='utf-8')
        print(f'Visual preview PASS: {out} ({len(sizes)} responsive sizes)')
    except Exception as e:
        print(f'Visual preview skipped: {e}')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
