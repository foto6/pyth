#!/usr/bin/env python3
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors=[]

def fail(msg): errors.append(msg)

# Parse all authored XML.
for path in (ROOT/'app/src/main').rglob('*.xml'):
    try: ET.parse(path)
    except Exception as e: fail(f'XML parse failed: {path.relative_to(ROOT)}: {e}')

# Manifest privacy/safety invariants.
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android.permission.INTERNET' in manifest: fail('INTERNET permission must not be present')
if 'android.permission.PACKAGE_USAGE_STATS' not in manifest: fail('PACKAGE_USAGE_STATS permission missing')
if 'android:allowBackup="false"' not in manifest: fail('app backup must stay disabled')
for pkg in ('org.mozilla.firefox','com.openai.chatgpt'):
    if pkg not in manifest: fail(f'package query missing: {pkg}')


# Widget RemoteViews must use host-safe view classes only.
widget_tree=ET.parse(ROOT/'app/src/main/res/layout/widget_daily_focus.xml').getroot()
allowed_widget_tags={'LinearLayout','TextView','ProgressBar','ImageView'}
for element in widget_tree.iter():
    tag=element.tag.split('}')[-1]
    if tag not in allowed_widget_tags:
        fail(f'unsupported RemoteViews widget tag: {tag}')

# Every R.id referenced by widget code must exist in widget XML.
widget_code=(ROOT/'app/src/main/java/com/foto6/dailyfocus/widget/DailyFocusWidgetProvider.kt').read_text(encoding='utf-8')
widget_xml=(ROOT/'app/src/main/res/layout/widget_daily_focus.xml').read_text(encoding='utf-8')
ids=set(re.findall(r'R\.id\.([A-Za-z0-9_]+)',widget_code))
xmlids=set(re.findall(r'@\+id/([A-Za-z0-9_]+)',widget_xml))
for x in sorted(ids-xmlids): fail(f'widget code references missing id: {x}')

# Resource references exist for the small app-owned resource set.
for kind in ('color','drawable','layout','xml'):
    refs=set()
    for path in (ROOT/'app/src/main').rglob('*'):
        if path.is_file() and path.suffix in {'.kt','.xml'}:
            try: txt=path.read_text(encoding='utf-8')
            except UnicodeDecodeError: continue
            refs.update(re.findall(rf'(?:R\.{kind}\.|@{kind}/)([A-Za-z0-9_]+)',txt))
    if kind=='color':
        txt=(ROOT/'app/src/main/res/values/colors.xml').read_text(encoding='utf-8')
        owned=set(re.findall(r'<color\s+name="([^"]+)"',txt))
    else:
        owned={p.stem for p in (ROOT/f'app/src/main/res/{kind}').glob('*')} if (ROOT/f'app/src/main/res/{kind}').exists() else set()
    # Ignore library/framework resources; only require app-prefixed refs and known owned refs.
    for ref in sorted(refs):
        if ref.startswith(('widget_','daily_focus','app_icon')) and ref not in owned:
            fail(f'missing @{kind}/{ref}')

# No accidental old "limit" semantics in UI/source.
for path in list((ROOT/'app/src/main/java').rglob('*.kt')) + [ROOT/'README.md']:
    txt=path.read_text(encoding='utf-8')
    if re.search(r'\b(limitMinutes|formatLimit|overLimit|DEFAULT_LIMIT|MIN_LIMIT|MAX_LIMIT)\b',txt):
        fail(f'legacy limit semantic remains in {path.relative_to(ROOT)}')

# Core files expected by packaging.
for rel in ['gradlew','gradle/wrapper/gradle-wrapper.jar','app/build.gradle.kts','app/src/main/AndroidManifest.xml']:
    if not (ROOT/rel).is_file(): fail(f'missing required file: {rel}')

# Background refresh must not be scheduled permanently just by opening the app.
main_activity=(ROOT/'app/src/main/java/com/foto6/dailyfocus/MainActivity.kt').read_text(encoding='utf-8')
widget_provider=(ROOT/'app/src/main/java/com/foto6/dailyfocus/widget/DailyFocusWidgetProvider.kt').read_text(encoding='utf-8')
if 'WorkScheduler.schedule(this)' in main_activity: fail('MainActivity must not permanently schedule widget worker')
if 'override fun onDisabled' not in widget_provider or 'WorkScheduler.cancel(context)' not in widget_provider:
    fail('widget worker must be cancelled when last widget is removed')

if errors:
    print('STATIC VERIFY FAILED')
    for e in errors: print(' -',e)
    sys.exit(1)
print(f'STATIC VERIFY PASS: XML/resources/manifest/widget ids/privacy invariants')
