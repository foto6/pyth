#!/usr/bin/env python3
"""Pure geometry/property stress test for the home-screen widget.

No files are written. This is intentionally fatal in CI if a supported widget size
would make the chosen content policy exceed the available height.
"""
from random import Random

PADDING_Y = 20
HEADER = 32
USAGE_BLOCK = 38       # top margin + large time text
PROGRESS = 9           # top margin + bar
STATUS = 29            # margin + pill
APPS = 50              # margin + app cards
TASK_HEADER = 27       # margin + heading
TASK_ROW = 28


def policy(width: int, height: int):
    width=max(width,0); height=max(height,0)
    narrow=width < 280
    if height < 210: return (False, False, False, 1)
    if height < 250: return (not narrow, False, False, 2)
    if height < 280: return (not narrow, True, False, 2)
    if height < 300: return (not narrow, True, True, 2)
    if height < 320: return (not narrow, True, True, 3)
    return (not narrow, True, True, 4)


def required_height(width: int, height: int):
    _, status, apps, max_tasks = policy(width,height)
    total=PADDING_Y+HEADER+USAGE_BLOCK+PROGRESS+TASK_HEADER+max_tasks*TASK_ROW
    if status: total += STATUS
    if apps: total += APPS
    return total


def check(width: int, height: int):
    layout=policy(width,height)
    need=required_height(width,height)
    # Only enforce sizes that Android can actually expose for this widget.
    if width >= 250 and height >= 185 and need > height:
        raise AssertionError(f'overflow at {width}x{height}: requires {need}px-equivalent dp, layout={layout}')
    if layout[2] and not layout[1]:
        raise AssertionError('apps may not be shown without status')
    if not 1 <= layout[3] <= 4:
        raise AssertionError('invalid maxTasks')
    if width < 280 and layout[0]:
        raise AssertionError('subtitle must be hidden on narrow widget')


def main():
    # Every threshold and common Samsung-ish size.
    widths=[250,260,279,280,300,320,360,420,520]
    heights=[185,200,209,210,230,249,250,270,279,280,290,299,300,310,319,320,340,360,420,520]
    for w in widths:
        for h in heights:
            check(w,h)

    # Deterministic randomized stress.
    rng=Random(0xD411F0C)
    for _ in range(100_000):
        check(rng.randint(0,900), rng.randint(0,1200))

    print('WIDGET STRESS PASS: thresholds + 100000 randomized sizes')

if __name__ == '__main__':
    main()
